#!/bin/bash
echo ok